
import unittest
from decimal import Decimal

from app.auxiliares import (
    validar_correo,
    validar_descripcion_producto,
    validar_fecha_nacimiento,
    validar_nombre_producto,
    validar_precio_producto,
    validar_rut,
    validar_sku_producto,
)

class TestValidaciones(unittest.TestCase):

    def test_rut_valido(self):
        rut, mensaje = validar_rut("12.345.678-5")
        self.assertEqual(rut, "12.345.678-5")
        self.assertEqual(mensaje, "RUT válido")

    def test_rut_invalido(self):
        rut, mensaje = validar_rut("11.111.111-9")
        self.assertEqual(rut, "")
        self.assertEqual(mensaje, "RUT inválido")

    def test_sku_producto_obligatorio_y_maximo(self):
        self.assertIsNone(validar_sku_producto(" ")[0])
        self.assertIsNone(validar_sku_producto("S" * 51)[0])
        self.assertEqual(validar_sku_producto(" SKU-1 ")[0], "SKU-1")

    def test_nombre_producto_obligatorio_y_maximo(self):
        self.assertIsNone(validar_nombre_producto(" ")[0])
        self.assertIsNone(validar_nombre_producto("N" * 256)[0])
        self.assertEqual(validar_nombre_producto(" Teclado ")[0], "Teclado")

    def test_precio_producto_debe_ser_decimal_valido(self):
        self.assertEqual(validar_precio_producto("12.50")[0], Decimal("12.50"))
        for precio in ("", "-1", "1.234", "NaN", "100000000", "texto"):
            with self.subTest(precio=precio):
                self.assertIsNone(validar_precio_producto(precio)[0])

    def test_correo_valido(self):
        correo, mensaje = validar_correo("juan.perez@example.com")
        self.assertEqual(correo, "juan.perez@example.com")
        self.assertEqual(mensaje, "Formato de correo correcto")

    def test_correo_invalido(self):
        correo, mensaje = validar_correo("correosinformatocorrecto.com")
        self.assertEqual(correo, "")
        self.assertEqual(mensaje, "Formato de correo incorrecto")

    def test_fecha_nacimiento_valida(self):
        fecha, mensaje = validar_fecha_nacimiento("15/05/1995")
        self.assertEqual(fecha, "15/05/1995")
        self.assertEqual(mensaje, "Formato de fecha correcto")

    def test_fecha_nacimiento_formato_invalido(self):
        fecha, mensaje = validar_fecha_nacimiento("1995-05-15")
        self.assertEqual(fecha, "")
        self.assertEqual(mensaje, "Formato de fecha NO corresponde, ingrese nuevamente...")

    def test_fecha_nacimiento_calendario_invalido(self):
        # Caso de valor límite / calendario inválido: 31 de febrero de 2024.
        # En la especificación esperada de negocio, una fecha de calendario inexistente debe rechazarse ("").
        # NOTA: En app/auxiliares/validaciones.py sólo se valida con expresión regular sintáctica dd/mm/yyyy,
        # por lo que este assert evidencia el bug existente al retornar ('31/02/2024', 'Formato de fecha correcto').
        fecha, mensaje = validar_fecha_nacimiento("31/02/2024")
        self.assertEqual(fecha, "")
        self.assertEqual(mensaje, "Formato de fecha NO corresponde, ingrese nuevamente...")

if __name__ == "__main__":
    unittest.main()
