import unittest
from datetime import datetime
from unittest.mock import MagicMock, patch

from peewee import ModelSelect
from prettytable import PrettyTable

from app.modelos.cliente import Cliente
from app.negocio.nego_cliente import cargar_cliente
from app.negocio.nego_detalle_pedido import _validar_cantidad


class TestNegocioCliente(unittest.TestCase):

    @patch("app.negocio.nego_cliente.cliente_por_rut")
    def test_cargar_cliente_simulando_repo_cliente_falla(self, mock_cliente_por_rut):
        # Simula cliente_por_rut tal como está implementado en repo_cliente.py (retorna un objeto query de Peewee).
        # En nego_cliente.py, cargar_cliente intenta acceder directamente a cliente.nombre_cliente,
        # lo que produce un AttributeError al ser un query y no una instancia del modelo Cliente.
        mock_query = MagicMock()
        del mock_query.nombre_cliente
        mock_cliente_por_rut.return_value = mock_query

        tabla = PrettyTable()
        with self.assertRaises(AttributeError):
            cargar_cliente(tabla, "12.345.678-5")

    @patch("app.negocio.nego_cliente.cliente_por_rut")
    def test_cargar_cliente_con_instancia_retorna_correctamente(self, mock_cliente_por_rut):
        # Verifica que cuando cliente_por_rut entrega una instancia válida de Cliente,
        # cargar_cliente llena la tabla y retorna la tupla (tabla, cliente).
        cliente = Cliente(
            id_cliente=1,
            rut_cliente="12.345.678-5",
            nombre_cliente="Juan",
            apellido_cliente="Perez",
            correo_cliente="juan@gmail.com",
            fecha_nacimiento_cliente="2000-12-25",
            fecha_incorporacion_cliente=datetime(2024, 1, 1),
            cliente_habilitado=True,
        )
        mock_cliente_por_rut.return_value = cliente

        tabla = PrettyTable()
        tabla_resultado, cliente_resultado = cargar_cliente(tabla, "12.345.678-5")

        self.assertEqual(cliente_resultado, cliente)
        self.assertEqual(cliente_resultado.rut_cliente, "12.345.678-5")
        self.assertEqual(cliente_resultado.nombre_cliente, "Juan")
        self.assertEqual(len(tabla_resultado.rows), 1)


class TestNegocioDetallePedido(unittest.TestCase):

    def test_validar_cantidad_valida(self):
        # Cantidad válida 5 (entero mayor a cero) no debe lanzar excepciones
        try:
            _validar_cantidad(5)
        except ValueError:
            self.fail("_validar_cantidad(5) lanzó ValueError inesperadamente")

    def test_validar_cantidad_invalida_cero(self):
        # Cantidad 0 debe lanzar ValueError
        with self.assertRaises(ValueError) as context:
            _validar_cantidad(0)
        self.assertIn("mayor que cero", str(context.exception))

    def test_validar_cantidad_invalida_negativa(self):
        # Cantidad -2 debe lanzar ValueError
        with self.assertRaises(ValueError) as context:
            _validar_cantidad(-2)
        self.assertIn("mayor que cero", str(context.exception))


if __name__ == "__main__":
    unittest.main()
