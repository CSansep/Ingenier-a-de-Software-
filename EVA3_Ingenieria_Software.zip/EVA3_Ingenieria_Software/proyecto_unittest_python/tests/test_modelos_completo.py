import time
import unittest
from datetime import datetime
from decimal import Decimal

from app.modelos.cliente import Cliente
from app.modelos.detalle_pedido import DetallePedido
from app.modelos.pedido import EstadoPedido, Pedido
from app.modelos.producto import Producto


class TestProducto(unittest.TestCase):

    def test_creacion_producto(self):
        producto = Producto(
            id_producto=1,
            sku_producto="PROD-001",
            nombre_producto="Laptop Gamer",
            descripcion_producto="Laptop 16GB RAM 512GB SSD",
            precio_producto=Decimal("899990.00"),
            producto_habilitado=True,
        )

        self.assertEqual(producto.id_producto, 1)
        self.assertEqual(producto.sku_producto, "PROD-001")
        self.assertEqual(producto.nombre_producto, "Laptop Gamer")
        self.assertEqual(producto.descripcion_producto, "Laptop 16GB RAM 512GB SSD")
        self.assertEqual(producto.precio_producto, Decimal("899990.00"))
        self.assertTrue(producto.producto_habilitado)
        self.assertEqual(str(producto), "Laptop Gamer - $899990.00")


class TestPedido(unittest.TestCase):

    def test_creacion_pedido(self):
        cliente = Cliente(
            id_cliente=1,
            rut_cliente="12.345.678-5",
            nombre_cliente="Juan",
            apellido_cliente="Perez",
            correo_cliente="juan@gmail.com",
            fecha_nacimiento_cliente="2000-12-25",
            fecha_incorporacion_cliente=datetime(2024, 1, 1),
            cliente_habilitado=True,
        )

        pedido = Pedido(
            id_pedido=1,
            cliente_pedido=cliente,
            total_pedido=Decimal("150000.00"),
            estado_pedido=EstadoPedido.PEND,
            pedido_habilitado=True,
        )

        self.assertEqual(pedido.id_pedido, 1)
        self.assertEqual(pedido.cliente_pedido, cliente)
        self.assertEqual(pedido.total_pedido, Decimal("150000.00"))
        self.assertEqual(pedido.estado_pedido, EstadoPedido.PEND)
        self.assertTrue(pedido.pedido_habilitado)
        self.assertEqual(str(pedido), "Pedido 1 - Total: $150000.00")

    def test_pedidos_fechas_distintos_momentos(self):
        # Verifica que dos pedidos creados en momentos distintos no tengan exactamente el mismo microsegundo.
        # NOTA: En app/modelos/pedido.py se definió `default=datetime.now()`, fijando la fecha en tiempo
        # de importación en lugar de evaluarse en cada instanciación. Este assert verifica dicha regla.
        pedido1 = Pedido()
        time.sleep(0.01)
        pedido2 = Pedido()
        self.assertNotEqual(pedido1.fecha_pedido, pedido2.fecha_pedido)


class TestDetallePedido(unittest.TestCase):

    def test_creacion_detalle_pedido(self):
        cliente = Cliente(
            id_cliente=1,
            rut_cliente="12.345.678-5",
            nombre_cliente="Juan",
            apellido_cliente="Perez",
            correo_cliente="juan@gmail.com",
            fecha_nacimiento_cliente="2000-12-25",
            fecha_incorporacion_cliente=datetime(2024, 1, 1),
            cliente_habilitado=True,
        )

        pedido = Pedido(
            id_pedido=1,
            cliente_pedido=cliente,
            total_pedido=Decimal("30000.00"),
            estado_pedido=EstadoPedido.PEND,
            pedido_habilitado=True,
        )

        producto = Producto(
            id_producto=10,
            sku_producto="TECL-01",
            nombre_producto="Teclado Mecánico",
            descripcion_producto="Teclado RGB Switch Blue",
            precio_producto=Decimal("30000.00"),
            producto_habilitado=True,
        )

        detalle = DetallePedido(
            id_detalle_pedido=1,
            id_pedido=pedido,
            id_producto=producto,
            cantidad=2,
            precio_unitario=Decimal("15000.00"),
            habilitado=True,
        )

        self.assertEqual(detalle.id_detalle_pedido, 1)
        self.assertEqual(detalle.id_pedido, pedido)
        self.assertEqual(detalle.id_producto, producto)
        self.assertEqual(detalle.cantidad, 2)
        self.assertEqual(detalle.precio_unitario, Decimal("15000.00"))
        self.assertTrue(detalle.habilitado)
        self.assertEqual(str(detalle), f"Pedido: {pedido} - Producto: {producto}")


if __name__ == "__main__":
    unittest.main()
